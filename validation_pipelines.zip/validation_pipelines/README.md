# BOLD Transcriptomic Validation Pipelines

Reproducible code for the **independent transcriptomic validation** of the BOLD
(Bistable Osteo-immune Logic for Design) framework, as reported in the
manuscript (Results §3.4 "Independent transcriptomic validation", Table 1).

These pipelines map three gene modules onto the three BOLD state variables and
test the model's pre-specified qualitative predictions in three independent
public GEO datasets.

| Module | BOLD variable | Biological meaning |
|:------:|:-------------:|:-------------------|
| **X** | inflammation | pro-inflammatory / ROS-generating activity |
| **Y** | osteogenesis | pro-osteogenic activity |
| **Z** | metabolic fitness | oxidative phosphorylation + M2-like program |

Composite regenerative score (identical to the ODE model):

```
RegScore = 0.4·Z + 0.4·Y + 0.2·(1 − X)      (X, Y, Z min-max normalised to [0,1])
```

---

## Datasets

| # | Accession | Assay | Comparison | Role |
|:-:|:---------:|:-----:|:----------:|:-----|
| 1 | **GSE234451** | murine fracture-healing snRNA-seq (13 502 nuclei) | Day 0 / 3 / 5 / 7 | attractor architecture, temporal escape, cell-type partitioning |
| 2 | **GSE240390** | murine fracture-callus bulk RNA-seq (30 samples) | Lean vs DIO, Day 3–21 | pathological checkpoint impairment |
| 3 | **GSE180504** | human BMSC bulk RNA-seq (6 samples) | Lean / Obese / T2D | pathological attractor deepening |

---

## Quick start

```bash
cd /workspace/group/validation_pipelines
bash run_all.sh
```

Or run individual pipelines:

```bash
python3 scripts/01_gse234451_snrna.py \
    --h5ad   /workspace/group/plotting_data/GSE234451_processed.h5ad \
    --outdir outputs

python3 scripts/02_gse240390_bulk.py \
    --counts /workspace/group/geo_data/GSE240390/GSE240390_raw_counts.csv \
    --outdir outputs

python3 scripts/03_gse180504_human_bmsc.py \
    --counts /workspace/group/geo_data/GSE180504_counts.txt \
    --outdir outputs

python3 scripts/04_validation_figure.py --outdir outputs
```

Override data locations with environment variables:

```bash
DATA_DIR=/path/to/data OUTDIR=/path/to/out bash run_all.sh
```

---

## Directory layout

```
validation_pipelines/
├── README.md
├── run_all.sh                       master runner
├── config/
│   └── gene_modules.py              X/Y/Z gene sets, M1/M2 markers,
│                                    cell-type markers, sample↔time maps
├── scripts/
│   ├── common.py                    minmax, regscore, Cohen's d, I/O helpers
│   ├── 01_gse234451_snrna.py        snRNA-seq pipeline
│   ├── 02_gse240390_bulk.py         bulk RNA-seq pipeline (Lean vs DIO)
│   ├── 03_gse180504_human_bmsc.py   human BMSC pipeline
│   └── 04_validation_figure.py      multi-panel validation figure
├── outputs/                         all results (created on first run)
│   ├── GSE234451/
│   ├── GSE240390/
│   ├── GSE180504/
│   └── Figure_validation_pipeline.{png,pdf}
└── logs/                            per-pipeline stdout logs
```

---

## Outputs

### `outputs/GSE234451/`
| File | Contents |
|:-----|:---------|
| `time_series_summary.csv` | X/Y/Z/RegScore mean ± SD per time point |
| `macrophage_scores.csv` | per-cell M1-like / M2-like scores (7 448 cells) |
| `macrophage_subtype_stats.csv` | subtype comparison: Δ, Cohen's d, Mann–Whitney p |
| `celltype_temporal.csv` | cell-type × time-point module scores |
| `gene_time_expression.csv` | marker-gene mean expression across time |
| `validation_summary.json` | machine-readable summary of P1/P2/P3/P7 |

### `outputs/GSE240390/`
| File | Contents |
|:-----|:---------|
| `module_scores.csv` | per-sample X/Y/Z + RegScore (30 samples) |
| `module_scores_summary.csv` | condition × day summary |
| `trajectory_stats.csv` | per-day Lean vs DIO comparison (two- and one-sided) |
| `day7_transition_test.csv` | the pre-specified Day-7 checkpoint test |
| `validation_summary.json` | machine-readable summary of P5 |

### `outputs/GSE180504/`
| File | Contents |
|:-----|:---------|
| `module_scores.csv` | per-sample X/Y/Z + RegScore (6 samples) |
| `regscore_summary.csv` | group-level RegScore (mean + replicates) |
| `group_comparison.csv` | pairwise directional comparisons |
| `validation_summary.json` | machine-readable summary of P4 |

---

## Reproduced results (manuscript Table 1)

| BOLD prediction | Dataset | Result | Agreement |
|:----------------|:-------:|:-------|:---------:|
| Metabolic-axis attractor architecture | GSE234451 | M2-like Z = +0.474 vs M1-like −0.121 (Δ = +0.595, d = 3.32, p < 1e-300) | ✓ |
| Inflammatory-axis architecture | GSE234451 | X did **not** segregate as predicted (Δ = +0.108, d = +0.56) | ✗ (reported explicitly) |
| Temporal escape trajectory | GSE234451 | X peaks at Day 5 (+0.064) and resolves by Day 7 (−0.013); RegScore 0.286 → 0.340 | ✓ |
| Cell-type partitioning | GSE234451 | Macrophages highest X; osteoblasts highest Y | ✓ |
| Pathological checkpoint impairment | GSE240390 | Day-7 ΔRegScore = −0.118; one-sided p = 0.050 (two-sided 0.101) | ✓ (preliminary) |
| Pathological attractor deepening | GSE180504 | T2D 0.341 vs Lean 0.472; Obese 0.551 (non-predicted direction) | ✓ (directional, n = 2) |
| Bifurcation threshold location | numerical | continuation 0.333; finite-time grid 0.338 (within 2%) | ✓ |

> **Note on P2.** The inflammatory-axis prediction was *not* confirmed at this
> resolution and is reported explicitly as a negative result in the manuscript.
> The pipeline reproduces this faithfully rather than tuning the analysis to
> force agreement.

---

## Environment

```
python >= 3.9
numpy, pandas, scipy
scanpy >= 1.9        (pipeline 01 only)
matplotlib           (pipeline 04 only)
```

Install:

```bash
pip install numpy pandas scipy scanpy matplotlib
```

---

## Notes on implementation

* **Module scoring.** Bulk datasets use the mean of `log2(CPM + 1)` across the
  genes detected in each module (18/23 mouse markers in GSE240390; 15/23 human
  orthologues in GSE180504). The snRNA-seq dataset uses Scanpy's
  `score_genes()` control-gene-corrected score, which is already stored in the
  AnnData object as `score_X` / `score_Y` / `score_Z`.
* **Normalisation.** The composite score is computed after min-max normalising
  X, Y and Z to [0, 1] *within each dataset*, so scores are comparable across
  datasets but not across studies with different dynamic ranges.
* **Statistics.** Between-subtype comparisons use two-sided Mann–Whitney U
  tests with Cohen's d effect sizes. The Day-7 checkpoint is a pre-specified
  directional prediction, so a one-sided Welch t-test is reported alongside the
  two-sided value for transparency.
* **Small samples.** GSE180504 has n = 2 per group; all comparisons there are
  explicitly labelled directional / hypothesis-generating.
* **Determinism.** No random seeds are used; all outputs are fully
  deterministic given the input files.

---

## Citation

If you use these pipelines, please cite the manuscript:

> Shen X., Chen Y., Fu C., Lu N. *Breaking the Inflammatory Attractor:
> Quantitative Design Rules for Smart Biomaterials from Integrated Evidence
> Synthesis and Dynamical Modelling.* (submitted)

Code repository: <https://github.com/ShenXinhecyy/bone-microenvironment-ode>
