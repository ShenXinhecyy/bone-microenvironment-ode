#!/usr/bin/env bash
# =============================================================================
# BOLD transcriptomic validation pipelines -- master runner
# =============================================================================
# Reproduces the independent transcriptomic validation of the BOLD framework
# reported in the manuscript (Results 3.4; Table 1).
#
# Datasets
#   GSE234451  murine fracture-healing snRNA-seq        (Perrin et al., eLife 2024)
#   GSE240390  murine fracture callus bulk RNA-seq      (Khajuria et al., 2023)
#   GSE180504  human BMSC bulk RNA-seq (Lean/Obese/T2D) (Figeac et al., 2022)
#
# Usage
#   bash run_all.sh                 # use default data paths
#   DATA_DIR=/path/to/data bash run_all.sh
# =============================================================================
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DATA_DIR="${DATA_DIR:-/workspace/group}"
OUTDIR="${OUTDIR:-${HERE}/outputs}"
LOGDIR="${HERE}/logs"
mkdir -p "$OUTDIR" "$LOGDIR"

PY="${PYTHON:-python3}"

echo "=============================================================="
echo " BOLD transcriptomic validation pipelines"
echo " data dir : $DATA_DIR"
echo " out dir  : $OUTDIR"
echo "=============================================================="

run() {
    local name="$1"; shift
    echo ""
    echo ">>> $name"
    "$PY" "$@" 2>&1 | tee "${LOGDIR}/${name}.log"
}

run 01_gse234451_snrna \
    "${HERE}/scripts/01_gse234451_snrna.py" \
    --h5ad   "${DATA_DIR}/plotting_data/GSE234451_processed.h5ad" \
    --outdir "${OUTDIR}"

run 02_gse240390_bulk \
    "${HERE}/scripts/02_gse240390_bulk.py" \
    --counts "${DATA_DIR}/geo_data/GSE240390/GSE240390_raw_counts.csv" \
    --outdir "${OUTDIR}"

run 03_gse180504_human_bmsc \
    "${HERE}/scripts/03_gse180504_human_bmsc.py" \
    --counts "${DATA_DIR}/geo_data/GSE180504_counts.txt" \
    --outdir "${OUTDIR}"

echo ""
echo ">>> 04_validation_figure"
"$PY" "${HERE}/scripts/04_validation_figure.py" \
    --outdir "${OUTDIR}" 2>&1 | tee "${LOGDIR}/04_validation_figure.log"

echo ""
echo "=============================================================="
echo " All pipelines complete."
echo " Results : $OUTDIR"
echo " Logs    : $LOGDIR"
echo "=============================================================="
