#!/usr/bin/env python3
"""
Validation figure -- assembles the outputs of pipelines 01-03 into a single
publication-style multi-panel figure.

Panels
------
    A  GSE234451  temporal escape trajectory (X, Y, Z, RegScore vs day)
    B  GSE234451  M1-like vs M2-like module scores (metabolic-axis separation)
    C  GSE240390  Lean vs DIO regenerative-score trajectory
    D  GSE240390  Day-7 checkpoint test (Lean vs DIO)
    E  GSE180504  Lean / Obese / T2D composite regenerative score
    F  Validation scorecard (prediction x dataset x agreement)

Usage
-----
    python 04_validation_figure.py --outdir /workspace/group/validation_pipelines/outputs
"""

from __future__ import annotations

import argparse
import json
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

# ---------------------------------------------------------------------------
# Style
# ---------------------------------------------------------------------------
plt.rcParams.update({
    "font.family": "DejaVu Sans",
    "font.size": 9,
    "axes.labelsize": 10,
    "axes.titlesize": 10,
    "xtick.labelsize": 9,
    "ytick.labelsize": 9,
    "legend.fontsize": 8.5,
    "figure.dpi": 300,
    "savefig.dpi": 300,
    "savefig.bbox": "tight",
    "axes.linewidth": 0.8,
    "axes.spines.top": False,
    "axes.spines.right": False,
    "lines.linewidth": 1.8,
})

C = {
    "X": "#C0392B",        # inflammation
    "Y": "#1F77B4",        # osteogenesis
    "Z": "#2E8B57",        # metabolic
    "score": "#6A3D9A",    # composite
    "lean": "#4C9F70",
    "dio": "#D1495B",
    "m1": "#D1495B",
    "m2": "#4C9F70",
    "grid": "#DDDDDD",
}


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--outdir", required=True)
    return p.parse_args()


def load(outdir, ds, fname):
    return pd.read_csv(os.path.join(outdir, ds, fname))


def main():
    args = parse_args()
    out = args.outdir

    ts = load(out, "GSE234451", "time_series_summary.csv")
    mac = load(out, "GSE234451", "macrophage_subtype_stats.csv")
    g240 = load(out, "GSE240390", "module_scores_summary.csv")
    d7 = load(out, "GSE240390", "day7_transition_test.csv")
    g180 = load(out, "GSE180504", "regscore_summary.csv")

    fig = plt.figure(figsize=(15, 9.5))
    gs = fig.add_gridspec(2, 3, hspace=0.42, wspace=0.32)

    # ------------------------------------------------------------------
    # A. GSE234451 temporal escape trajectory
    # ------------------------------------------------------------------
    ax = fig.add_subplot(gs[0, 0])
    for var, col, lab in [("X", C["X"], "X  inflammation"),
                          ("Y", C["Y"], "Y  osteogenesis"),
                          ("Z", C["Z"], "Z  metabolic")]:
        ax.errorbar(ts["time_point"], ts[f"{var}_mean"], yerr=ts[f"{var}_std"],
                    marker="o", ms=5, capsize=3, color=col, label=lab)
    ax.axhline(0, color="grey", lw=0.7, ls=":")
    ax.set_xlabel("Days post-fracture")
    ax.set_ylabel("Module score (z-like)")
    ax.set_title("A  GSE234451: temporal escape trajectory", loc="left", fontweight="bold")
    ax.set_xticks(ts["time_point"])
    ax.legend(frameon=False, loc="upper left")
    ax.grid(alpha=0.25, color=C["grid"])

    # ------------------------------------------------------------------
    # B. GSE234451 M1-like vs M2-like
    # ------------------------------------------------------------------
    ax = fig.add_subplot(gs[0, 1])
    order = ["score_X", "score_Y", "score_Z", "RegScore"]
    labels = ["X", "Y", "Z", "RegScore"]
    xpos = np.arange(len(order))
    w = 0.36
    m1v = [mac.set_index("variable").loc[v, "M1_like_mean"] for v in order]
    m2v = [mac.set_index("variable").loc[v, "M2_like_mean"] for v in order]
    ax.bar(xpos - w / 2, m1v, w, color=C["m1"], label="M1-like (n=5,573)")
    ax.bar(xpos + w / 2, m2v, w, color=C["m2"], label="M2-like (n=1,875)")
    for i, v in enumerate(order):
        d = mac.set_index("variable").loc[v, "cohens_d"]
        ax.text(i, max(m1v[i], m2v[i]) + 0.06, f"d={d:.2f}",
                ha="center", fontsize=8, color="#333333")
    ax.axhline(0, color="black", lw=0.8)
    ax.set_xticks(xpos)
    ax.set_xticklabels(labels)
    ax.set_ylabel("Mean module score")
    ax.set_title("B  GSE234451: macrophage attractor states", loc="left", fontweight="bold")
    ax.legend(frameon=False, loc="upper left")
    ax.grid(alpha=0.25, axis="y", color=C["grid"])

    # ------------------------------------------------------------------
    # C. GSE240390 Lean vs DIO trajectory
    # ------------------------------------------------------------------
    ax = fig.add_subplot(gs[0, 2])
    for cond, col in [("Lean", C["lean"]), ("DIO", C["dio"])]:
        sub = g240[g240["condition"] == cond]
        ax.errorbar(sub["day"], sub["RegScore_mean"], yerr=sub["RegScore_sd"],
                    marker="o", ms=5, capsize=3, color=col, label=cond)
    ax.axvline(7, color="#888888", ls="--", lw=1.0)
    ax.text(7.15, ax.get_ylim()[0] + 0.02, "Day-7\ncheckpoint", fontsize=8, color="#555555")
    ax.set_xlabel("Days post-fracture")
    ax.set_ylabel("Composite regenerative score")
    ax.set_title("C  GSE240390: Lean vs DIO healing", loc="left", fontweight="bold")
    ax.legend(frameon=False)
    ax.grid(alpha=0.25, color=C["grid"])

    # ------------------------------------------------------------------
    # D. GSE240390 Day-7 checkpoint
    # ------------------------------------------------------------------
    ax = fig.add_subplot(gs[1, 0])
    d7r = d7[d7["variable"] == "RegScore"].iloc[0]
    d7y = d7[d7["variable"] == "Y"].iloc[0]
    groups = ["RegScore", "Y"]
    lean_v = [d7r["Lean_mean"], d7y["Lean_mean"]]
    dio_v = [d7r["DIO_mean"], d7y["DIO_mean"]]
    xpos = np.arange(2)
    ax.bar(xpos - w / 2, lean_v, w, color=C["lean"], label="Lean")
    ax.bar(xpos + w / 2, dio_v, w, color=C["dio"], label="DIO")
    for i, (lv, dv) in enumerate(zip(lean_v, dio_v)):
        ax.text(i, max(lv, dv) * 1.01, f"Δ={dv - lv:+.3f}", ha="center", fontsize=8.5)
    ax.set_xticks(xpos)
    ax.set_xticklabels(["RegScore", "Y (osteogenic)"])
    ax.set_ylabel("Day-7 mean")
    ax.set_title("D  GSE240390: Day-7 checkpoint test", loc="left", fontweight="bold")
    ax.legend(frameon=False)
    ax.grid(alpha=0.25, axis="y", color=C["grid"])
    ax.text(0.98, 0.04,
            f"RegScore: one-sided p = {d7r['p_one_sided_DIO_less']:.3f}\n"
            f"(two-sided p = {d7r['p_two_sided']:.3f})",
            transform=ax.transAxes, ha="right", va="bottom", fontsize=8, color="#444444")

    # ------------------------------------------------------------------
    # E. GSE180504 Lean / Obese / T2D
    # ------------------------------------------------------------------
    ax = fig.add_subplot(gs[1, 1])
    g180 = g180.set_index("Condition").loc[["Lean", "Obese", "T2D"]].reset_index()
    cols = [C["lean"], "#E8A33D", C["dio"]]
    bars = ax.bar(g180["Condition"], g180["RegScore_mean"], color=cols, width=0.6)
    for i, r in g180.iterrows():
        ax.scatter([i, i], [r["RegScore_replicate1"], r["RegScore_replicate2"]],
                   color="black", s=22, zorder=3)
    for i, r in g180.iterrows():
        ax.text(i, r["RegScore_mean"] + 0.03, f"{r['RegScore_mean']:.3f}",
                ha="center", fontsize=9)
    ax.set_ylabel("Composite regenerative score")
    ax.set_ylim(0, 0.85)
    ax.set_title("E  GSE180504: human BMSC (n=2/group)", loc="left", fontweight="bold")
    ax.grid(alpha=0.25, axis="y", color=C["grid"])
    ax.text(0.5, 0.94, "directional only", transform=ax.transAxes,
            ha="center", fontsize=8, style="italic", color="#777777")

    # ------------------------------------------------------------------
    # F. Validation scorecard
    # ------------------------------------------------------------------
    ax = fig.add_subplot(gs[1, 2])
    ax.axis("off")
    rows = [
        ("Metabolic-axis architecture", "GSE234451", "✓"),
        ("Inflammatory-axis architecture", "GSE234451", "✗"),
        ("Temporal escape trajectory", "GSE234451", "✓"),
        ("Cell-type partitioning", "GSE234451", "✓"),
        ("Pathological checkpoint (Day 7)", "GSE240390", "✓"),
        ("Pathological deepening (T2D)", "GSE180504", "✓*"),
        ("Bifurcation threshold kROS*", "numerical", "✓"),
    ]
    ax.set_title("F  Validation scorecard", loc="left", fontweight="bold")
    y = 0.90
    ax.text(0.02, y + 0.06, "BOLD prediction", fontsize=9, fontweight="bold")
    ax.text(0.72, y + 0.06, "Dataset", fontsize=9, fontweight="bold")
    ax.text(0.94, y + 0.06, "Agr.", fontsize=9, fontweight="bold")
    for name, ds, mark in rows:
        col = "#2E8B57" if mark.startswith("✓") else "#C0392B"
        ax.text(0.02, y, name, fontsize=8.5)
        ax.text(0.72, y, ds, fontsize=8.5, color="#555555")
        ax.text(0.94, y, mark, fontsize=10, color=col, fontweight="bold")
        y -= 0.115
    ax.text(0.02, y - 0.02, "* directional, n = 2 per group", fontsize=7.5,
            style="italic", color="#777777")

    fig.suptitle("Independent transcriptomic validation of the BOLD framework",
                 fontsize=13, fontweight="bold", y=0.985)

    png = os.path.join(out, "Figure_validation_pipeline.png")
    pdf = os.path.join(out, "Figure_validation_pipeline.pdf")
    fig.savefig(png)
    fig.savefig(pdf)
    print(f"[figure] {png}")
    print(f"[figure] {pdf}")


if __name__ == "__main__":
    main()
