#!/usr/bin/env python3
"""
Validation pipeline 1 -- GSE234451
==================================

Murine fracture-healing single-nucleus RNA-seq (Perrin et al., eLife 2024).

Inputs
------
    <data-dir>/GSE234451_processed.h5ad
        AnnData with 13 502 nuclei x 22 562 genes, already QC-filtered and
        log-normalised, with per-cell ``score_X`` / ``score_Y`` / ``score_Z``
        (Scanpy ``score_genes``) and ``sample`` / ``gsm`` annotations.

Outputs (written to <out-dir>/GSE234451/)
-----------------------------------------
    time_series_summary.csv        X/Y/Z/RegScore per time point
    macrophage_scores.csv          per-cell M1-like / M2-like scores
    macrophage_subtype_stats.csv   subtype comparison (Wilcoxon + Cohen's d)
    celltype_temporal.csv          cell-type x time-point module scores
    gene_time_expression.csv       marker-gene mean expression across time
    validation_summary.json        machine-readable summary of all tests

Tests performed (manuscript Table 1)
------------------------------------
    P1  Metabolic-axis attractor architecture  (M2-like Z > M1-like Z)
    P2  Inflammatory-axis architecture         (M1-like X > M2-like X)
    P3  Temporal escape trajectory             (X peaks then resolves; score rises)
    P7  Cell-type partitioning                 (macrophages = X gatekeepers,
                                                osteoblasts = Y executors)

Usage
-----
    python 01_gse234451_snrna.py \
        --h5ad /workspace/group/plotting_data/GSE234451_processed.h5ad \
        --outdir /workspace/group/validation_pipelines/outputs
"""

from __future__ import annotations

import argparse
import os
import sys

import numpy as np
import pandas as pd
import scanpy as sc
from scipy import stats

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "config"))

from common import cohens_d, ensure_dir, regscore, write_json  # noqa: E402
from gene_modules import (  # noqa: E402
    CELLTYPE_MARKERS,
    GSE234451_SAMPLE_TIME,
    M1_MARKERS,
    M2_MARKERS,
)


def parse_args():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--h5ad", required=True, help="Path to GSE234451_processed.h5ad")
    p.add_argument("--outdir", required=True, help="Root output directory")
    p.add_argument("--m1m2-margin", type=float, default=0.1,
                   help="Margin by which one polarisation score must exceed the other (default 0.1)")
    return p.parse_args()


def main():
    args = parse_args()
    outdir = ensure_dir(os.path.join(args.outdir, "GSE234451"))
    print(f"[GSE234451] reading {args.h5ad}")
    adata = sc.read_h5ad(args.h5ad)
    adata.obs_names_make_unique()
    print(f"[GSE234451] {adata.n_obs} nuclei x {adata.n_vars} genes")

    # ------------------------------------------------------------------
    # 0. Annotate time points and composite score
    # ------------------------------------------------------------------
    adata.obs["time_point"] = adata.obs["sample"].map(GSE234451_SAMPLE_TIME)
    if adata.obs["time_point"].isna().any():
        missing = sorted(adata.obs.loc[adata.obs["time_point"].isna(), "sample"].unique())
        raise ValueError(f"Unmapped samples: {missing}")

    adata.obs["RegScore"] = regscore(
        adata.obs["score_X"].values,
        adata.obs["score_Y"].values,
        adata.obs["score_Z"].values,
        normalise=True,
    )

    # ------------------------------------------------------------------
    # 1. Temporal summary (P3)
    # ------------------------------------------------------------------
    ts = (
        adata.obs.groupby("time_point")
        .agg(
            X_mean=("score_X", "mean"), X_std=("score_X", "std"),
            Y_mean=("score_Y", "mean"), Y_std=("score_Y", "std"),
            Z_mean=("score_Z", "mean"), Z_std=("score_Z", "std"),
            RegScore_mean=("RegScore", "mean"), RegScore_std=("RegScore", "std"),
            N_cells=("RegScore", "count"),
        )
        .round(4)
    )
    ts.to_csv(os.path.join(outdir, "time_series_summary.csv"))
    print("[GSE234451] time_series_summary.csv")
    print(ts.to_string())

    # ------------------------------------------------------------------
    # 2. Macrophage polarisation (P1, P2)
    # ------------------------------------------------------------------
    m1_found = [g for g in M1_MARKERS if g in adata.var_names]
    m2_found = [g for g in M2_MARKERS if g in adata.var_names]
    print(f"[GSE234451] M1 markers found: {m1_found}")
    print(f"[GSE234451] M2 markers found: {m2_found}")

    sc.tl.score_genes(adata, m1_found, score_name="M1_score")
    sc.tl.score_genes(adata, m2_found, score_name="M2_score")

    adata.obs["macrophage_subtype"] = "Other"
    adata.obs.loc[adata.obs["M1_score"] > adata.obs["M2_score"] + args.m1m2_margin,
                  "macrophage_subtype"] = "M1_like"
    adata.obs.loc[adata.obs["M2_score"] > adata.obs["M1_score"] + args.m1m2_margin,
                  "macrophage_subtype"] = "M2_like"

    mac = adata.obs[adata.obs["macrophage_subtype"].isin(["M1_like", "M2_like"])].copy()
    mac_cols = ["macrophage_subtype", "score_X", "score_Y", "score_Z",
                "RegScore", "M1_score", "M2_score", "time_point"]
    mac[mac_cols].to_csv(os.path.join(outdir, "macrophage_scores.csv"))
    print(f"[GSE234451] macrophage_scores.csv ({len(mac)} cells)")

    m1 = mac[mac["macrophage_subtype"] == "M1_like"]
    m2 = mac[mac["macrophage_subtype"] == "M2_like"]

    stats_rows = []
    for var in ["score_X", "score_Y", "score_Z", "RegScore"]:
        a, b = m2[var].values, m1[var].values
        u, p = stats.mannwhitneyu(a, b, alternative="two-sided")
        stats_rows.append({
            "variable": var,
            "M2_like_mean": round(float(a.mean()), 4),
            "M1_like_mean": round(float(b.mean()), 4),
            "delta_M2_minus_M1": round(float(a.mean() - b.mean()), 4),
            "cohens_d": round(cohens_d(a, b), 4),
            "mannwhitney_U": float(u),
            "p_value": float(p),
            "n_M1_like": int(len(b)),
            "n_M2_like": int(len(a)),
        })
    subtype_stats = pd.DataFrame(stats_rows)
    subtype_stats.to_csv(os.path.join(outdir, "macrophage_subtype_stats.csv"), index=False)
    print("[GSE234451] macrophage_subtype_stats.csv")
    print(subtype_stats.to_string(index=False))

    # ------------------------------------------------------------------
    # 3. Cell-type partitioning (P7)
    # ------------------------------------------------------------------
    for ct, genes in CELLTYPE_MARKERS.items():
        found = [g for g in genes if g in adata.var_names]
        if len(found) >= 2:
            sc.tl.score_genes(adata, found, score_name=f"ctype_{ct}")

    ctype_cols = [c for c in adata.obs.columns if c.startswith("ctype_")]
    adata.obs["cell_type"] = (
        adata.obs[ctype_cols].idxmax(axis=1).str.replace("ctype_", "", regex=False)
    )

    ct_time = (
        adata.obs.groupby(["time_point", "cell_type"])
        .agg(
            X_mean=("score_X", "mean"), Y_mean=("score_Y", "mean"),
            Z_mean=("score_Z", "mean"), RegScore_mean=("RegScore", "mean"),
            N_cells=("RegScore", "count"),
        )
        .round(4)
        .reset_index()
    )
    ct_time.to_csv(os.path.join(outdir, "celltype_temporal.csv"), index=False)
    print("[GSE234451] celltype_temporal.csv")

    # ------------------------------------------------------------------
    # 4. Marker-gene expression across time (raw log-normalised values)
    # ------------------------------------------------------------------
    marker_genes = sorted(set(sum(CELLTYPE_MARKERS.values(), []) + M1_MARKERS + M2_MARKERS))
    marker_genes = [g for g in marker_genes if g in adata.var_names]
    expr = pd.DataFrame(
        np.asarray(adata[:, marker_genes].X.todense()) if hasattr(adata.X, "todense")
        else np.asarray(adata[:, marker_genes].X),
        columns=marker_genes,
        index=adata.obs_names,
    )
    expr["time_point"] = adata.obs["time_point"].values
    gene_time = (
        expr.groupby("time_point").mean().T
        .reset_index().rename(columns={"index": "Gene"})
        .melt(id_vars="Gene", var_name="Time_point", value_name="Mean_expression")
        .round(5)
    )
    gene_time.to_csv(os.path.join(outdir, "gene_time_expression.csv"), index=False)
    print("[GSE234451] gene_time_expression.csv")

    # ------------------------------------------------------------------
    # 5. Machine-readable validation summary
    # ------------------------------------------------------------------
    def _row(var):
        return subtype_stats.set_index("variable").loc[var].to_dict()

    x_peak_day = int(ts["X_mean"].idxmax())
    x_peak = float(ts["X_mean"].max())
    x_final = float(ts["X_mean"].iloc[-1])
    score_first = float(ts["RegScore_mean"].iloc[0])
    score_last = float(ts["RegScore_mean"].iloc[-1])

    summary = {
        "dataset": "GSE234451",
        "n_nuclei": int(adata.n_obs),
        "n_genes": int(adata.n_vars),
        "n_M1_like": int(len(m1)),
        "n_M2_like": int(len(m2)),
        "predictions": {
            "P1_metabolic_axis": {
                "test": "M2-like Z > M1-like Z (Mann-Whitney U, two-sided)",
                "delta_Z": _row("score_Z")["delta_M2_minus_M1"],
                "cohens_d": _row("score_Z")["cohens_d"],
                "p_value": _row("score_Z")["p_value"],
                "supported": bool(_row("score_Z")["delta_M2_minus_M1"] > 0),
            },
            "P2_inflammatory_axis": {
                "test": "M1-like X > M2-like X (Mann-Whitney U, two-sided)",
                "delta_X": _row("score_X")["delta_M2_minus_M1"],
                "cohens_d": _row("score_X")["cohens_d"],
                "p_value": _row("score_X")["p_value"],
                "supported": bool(_row("score_X")["delta_M2_minus_M1"] < 0),
            },
            "P3_temporal_escape": {
                "test": "X peaks then resolves; RegScore rises over healing",
                "X_peak_day": x_peak_day,
                "X_peak_value": round(x_peak, 4),
                "X_final_value": round(x_final, 4),
                "RegScore_day0": round(score_first, 4),
                "RegScore_final": round(score_last, 4),
                "supported": bool(x_peak_day not in (0, int(ts.index.max())) and score_last > score_first),
            },
            "P7_celltype_partitioning": {
                "test": "Macrophages highest X; osteoblasts highest Y",
                "macrophage_X_rank_by_day": {
                    int(d): int(
                        ct_time[ct_time["time_point"] == d]
                        .sort_values("X_mean", ascending=False)
                        .reset_index(drop=True)
                        .query("cell_type == 'Macrophage'").index[0] + 1
                    )
                    for d in sorted(ct_time["time_point"].unique())
                    if "Macrophage" in set(ct_time[ct_time["time_point"] == d]["cell_type"])
                },
                "osteoblast_Y_by_day": {
                    int(r.time_point): round(float(r.Y_mean), 4)
                    for r in ct_time[ct_time["cell_type"] == "Osteoblast"].itertuples()
                },
            },
        },
    }
    write_json(summary, os.path.join(outdir, "validation_summary.json"))
    print("[GSE234451] validation_summary.json")
    print(f"[GSE234451] done -> {outdir}")


if __name__ == "__main__":
    main()
