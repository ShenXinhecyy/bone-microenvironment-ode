#!/usr/bin/env python3
"""
Validation pipeline 2 -- GSE240390
==================================

Murine tibial fracture-callus bulk RNA-seq, lean vs diet-induced obesity (DIO)
(Khajuria et al., 2023; PMID 37854593).

Inputs
------
    <data-dir>/GSE240390_raw_counts.csv
        Raw count matrix, genes (Ensembl) x 30 samples (columns X1..X70).
    <data-dir>/GSE240390_series_matrix.txt.gz   (optional, for provenance)

Outputs (written to <out-dir>/GSE240390/)
-----------------------------------------
    module_scores.csv              per-sample X/Y/Z + RegScore
    module_scores_summary.csv      condition x day summary
    day7_transition_test.csv       Day-7 Lean vs DIO checkpoint test
    trajectory_stats.csv           per-day Lean vs DIO comparison
    validation_summary.json        machine-readable summary

Tests performed (manuscript Table 1)
------------------------------------
    P5  Pathological checkpoint impairment
        DIO impairs the Day-7 inflammatory-to-osteogenic transition.
        Pre-specified directional prediction -> one-sided t-test reported
        alongside the two-sided value.

Usage
-----
    python 02_gse240390_bulk.py \
        --counts /workspace/group/geo_data/GSE240390/GSE240390_raw_counts.csv \
        --outdir /workspace/group/validation_pipelines/outputs
"""

from __future__ import annotations

import argparse
import os
import sys

import numpy as np
import pandas as pd
from scipy import stats

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "config"))

from common import cohens_d, ensure_dir, regscore, write_json  # noqa: E402
from gene_modules import (  # noqa: E402
    ENSEMBL_TO_SYMBOL_MOUSE,
    GSE240390_SAMPLE_MAP,
    MOUSE_MODULES,
    parse_gse240390_sample,
)


def parse_args():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--counts", required=True, help="GSE240390_raw_counts.csv")
    p.add_argument("--outdir", required=True, help="Root output directory")
    return p.parse_args()


def cpm_log2(counts: pd.DataFrame) -> pd.DataFrame:
    """Counts -> log2(CPM + 1)."""
    lib = counts.sum(axis=0)
    cpm = counts.div(lib, axis=1) * 1e6
    return np.log2(cpm + 1)


def main():
    args = parse_args()
    outdir = ensure_dir(os.path.join(args.outdir, "GSE240390"))
    print(f"[GSE240390] reading {args.counts}")
    counts = pd.read_csv(args.counts, index_col=0)
    print(f"[GSE240390] raw matrix: {counts.shape[0]} genes x {counts.shape[1]} samples")

    # ------------------------------------------------------------------
    # 0. Rename columns X1..X70 -> D3_Lean_1 etc.
    # ------------------------------------------------------------------
    counts.columns = [GSE240390_SAMPLE_MAP.get(c, c) for c in counts.columns]
    unmapped = [c for c in counts.columns if c.startswith("X")]
    if unmapped:
        raise ValueError(f"Unmapped sample columns: {unmapped}")

    # ------------------------------------------------------------------
    # 1. Map Ensembl -> symbol, build log2(CPM+1) matrix
    # ------------------------------------------------------------------
    log2cpm = cpm_log2(counts)
    log2cpm.index = [ENSEMBL_TO_SYMBOL_MOUSE.get(i, i) for i in log2cpm.index]
    log2cpm = log2cpm[~log2cpm.index.duplicated(keep="first")]

    detected = {m: [g for g in genes if g in log2cpm.index]
                for m, genes in MOUSE_MODULES.items()}
    n_detected = sum(len(v) for v in detected.values())
    n_total = sum(len(v) for v in MOUSE_MODULES.values())
    print(f"[GSE240390] marker genes detected: {n_detected}/{n_total}")
    for m, g in detected.items():
        print(f"    {m}: {len(g)}/{len(MOUSE_MODULES[m])} -> {g}")

    # ------------------------------------------------------------------
    # 2. Module scores + composite regenerative score
    # ------------------------------------------------------------------
    scores = pd.DataFrame({
        m: log2cpm.loc[detected[m]].mean(axis=0) for m in ["X", "Y", "Z"]
    })
    scores["RegScore"] = regscore(scores["X"], scores["Y"], scores["Z"], normalise=True)

    meta = pd.DataFrame(
        [parse_gse240390_sample(s) for s in scores.index],
        columns=["day", "condition", "rep"],
        index=scores.index,
    )
    scores = pd.concat([scores, meta], axis=1)
    scores.index.name = "Sample"
    scores = scores.sort_values(["day", "condition", "Sample"])
    scores.round(5).to_csv(os.path.join(outdir, "module_scores.csv"))
    print("[GSE240390] module_scores.csv")

    summary = (
        scores.groupby(["condition", "day"])
        .agg(
            X_mean=("X", "mean"), X_sd=("X", "std"),
            Y_mean=("Y", "mean"), Y_sd=("Y", "std"),
            Z_mean=("Z", "mean"), Z_sd=("Z", "std"),
            RegScore_mean=("RegScore", "mean"), RegScore_sd=("RegScore", "std"),
            N=("RegScore", "count"),
        )
        .round(4)
    )
    summary.to_csv(os.path.join(outdir, "module_scores_summary.csv"))
    print("[GSE240390] module_scores_summary.csv")
    print(summary.to_string())

    # ------------------------------------------------------------------
    # 3. Per-day Lean vs DIO comparison
    # ------------------------------------------------------------------
    rows = []
    for day in sorted(scores["day"].unique()):
        sub = scores[scores["day"] == day]
        lean = sub[sub["condition"] == "Lean"]
        dio = sub[sub["condition"] == "DIO"]
        if len(lean) < 2 or len(dio) < 2:
            continue
        for var in ["X", "Y", "Z", "RegScore"]:
            a, b = dio[var].values, lean[var].values
            t2 = stats.ttest_ind(a, b, equal_var=False)
            # one-sided: DIO < Lean (pre-specified direction for the
            # regenerative checkpoint)
            t1 = stats.ttest_ind(a, b, equal_var=False, alternative="less")
            rows.append({
                "day": int(day),
                "variable": var,
                "Lean_mean": round(float(b.mean()), 4),
                "DIO_mean": round(float(a.mean()), 4),
                "delta_DIO_minus_Lean": round(float(a.mean() - b.mean()), 4),
                "cohens_d": round(cohens_d(a, b), 4),
                "t_two_sided": round(float(t2.statistic), 4),
                "p_two_sided": round(float(t2.pvalue), 4),
                "p_one_sided_DIO_less": round(float(t1.pvalue), 4),
                "n_Lean": int(len(b)),
                "n_DIO": int(len(a)),
            })
    traj = pd.DataFrame(rows)
    traj.to_csv(os.path.join(outdir, "trajectory_stats.csv"), index=False)
    print("[GSE240390] trajectory_stats.csv")

    # ------------------------------------------------------------------
    # 4. Day-7 checkpoint test (the pre-specified prediction)
    # ------------------------------------------------------------------
    d7 = traj[(traj["day"] == 7)].copy()
    d7.to_csv(os.path.join(outdir, "day7_transition_test.csv"), index=False)
    print("[GSE240390] day7_transition_test.csv")
    print(d7.to_string(index=False))

    d7_score = d7[d7["variable"] == "RegScore"].iloc[0]
    d7_y = d7[d7["variable"] == "Y"].iloc[0]

    # ------------------------------------------------------------------
    # 5. Machine-readable summary
    # ------------------------------------------------------------------
    summary_json = {
        "dataset": "GSE240390",
        "n_samples": int(len(scores)),
        "n_genes_raw": int(counts.shape[0]),
        "marker_genes_detected": n_detected,
        "marker_genes_total": n_total,
        "detected_by_module": {m: detected[m] for m in detected},
        "predictions": {
            "P5_day7_checkpoint": {
                "test": "DIO < Lean at Day 7 (Welch t-test; one-sided pre-specified)",
                "RegScore_Lean": float(d7_score["Lean_mean"]),
                "RegScore_DIO": float(d7_score["DIO_mean"]),
                "delta_RegScore": float(d7_score["delta_DIO_minus_Lean"]),
                "p_one_sided": float(d7_score["p_one_sided_DIO_less"]),
                "p_two_sided": float(d7_score["p_two_sided"]),
                "Y_Lean": float(d7_y["Lean_mean"]),
                "Y_DIO": float(d7_y["DIO_mean"]),
                "delta_Y": float(d7_y["delta_DIO_minus_Lean"]),
                "supported": bool(d7_score["delta_DIO_minus_Lean"] < 0),
            },
        },
        "trajectory": {
            "Lean_RegScore_by_day": {
                int(r.day): round(float(r.RegScore_mean), 4)
                for r in summary.loc["Lean"].reset_index().itertuples()
            },
            "DIO_RegScore_by_day": {
                int(r.day): round(float(r.RegScore_mean), 4)
                for r in summary.loc["DIO"].reset_index().itertuples()
            },
        },
    }
    write_json(summary_json, os.path.join(outdir, "validation_summary.json"))
    print("[GSE240390] validation_summary.json")
    print(f"[GSE240390] done -> {outdir}")


if __name__ == "__main__":
    main()
