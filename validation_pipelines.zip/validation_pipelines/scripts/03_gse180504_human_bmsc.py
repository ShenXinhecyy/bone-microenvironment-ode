#!/usr/bin/env python3
"""
Validation pipeline 3 -- GSE180504
==================================

Human bone-marrow stromal cell (BMSC) bulk RNA-seq, differentiated to
osteoblasts in the presence of serum from Lean, Obese or Type-2-diabetic (T2D)
donors (Figeac et al., Stem Cells 2022; PMID 35257177).

Inputs
------
    <data-dir>/GSE180504_counts.txt
        DESeq2-processed table with raw counts, rlog and normalised counts
        for 6 samples (n = 2 per group) plus a ``Symbol`` column.

Outputs (written to <out-dir>/GSE180504/)
-----------------------------------------
    module_scores.csv          per-sample X/Y/Z + RegScore
    regscore_summary.csv       group-level RegScore (mean + replicates)
    group_comparison.csv       pairwise group comparisons
    validation_summary.json    machine-readable summary

Tests performed (manuscript Table 1)
------------------------------------
    P4  Pathological attractor deepening (T2D lowers the regenerative score).
        n = 2 per group -> reported as directional / hypothesis-generating only.

Usage
-----
    python 03_gse180504_human_bmsc.py \
        --counts /workspace/group/geo_data/GSE180504_counts.txt \
        --outdir /workspace/group/validation_pipelines/outputs
"""

from __future__ import annotations

import argparse
import os
import sys

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "config"))

from common import ensure_dir, regscore, write_json  # noqa: E402
from gene_modules import HUMAN_MODULES  # noqa: E402

GROUPS = ["Lean", "Obese", "T2D"]


def parse_args():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--counts", required=True, help="GSE180504_counts.txt")
    p.add_argument("--outdir", required=True, help="Root output directory")
    return p.parse_args()


def main():
    args = parse_args()
    outdir = ensure_dir(os.path.join(args.outdir, "GSE180504"))
    print(f"[GSE180504] reading {args.counts}")
    df = pd.read_csv(args.counts, sep="\t")
    print(f"[GSE180504] table: {df.shape[0]} rows x {df.shape[1]} columns")

    # ------------------------------------------------------------------
    # 0. Locate the raw-count columns and the gene-symbol column
    # ------------------------------------------------------------------
    raw_cols = [c for c in df.columns if c.startswith("raw_")]
    if not raw_cols:
        raise ValueError("No 'raw_*' count columns found in GSE180504_counts.txt")
    if "Symbol" not in df.columns:
        raise ValueError("No 'Symbol' column found in GSE180504_counts.txt")

    counts = df[raw_cols].copy()
    counts.columns = [c.replace("raw_", "").strip() for c in raw_cols]
    counts.index = df["Symbol"].astype(str)
    counts = counts[~counts.index.duplicated(keep="first")]
    print(f"[GSE180504] samples: {list(counts.columns)}")

    # ------------------------------------------------------------------
    # 1. CPM -> log2(CPM + 1)
    # ------------------------------------------------------------------
    lib = counts.sum(axis=0)
    log2cpm = np.log2(counts.div(lib, axis=1) * 1e6 + 1)

    detected = {m: [g for g in genes if g in log2cpm.index]
                for m, genes in HUMAN_MODULES.items()}
    n_detected = sum(len(v) for v in detected.values())
    n_total = sum(len(v) for v in HUMAN_MODULES.values())
    print(f"[GSE180504] human orthologue markers detected: {n_detected}/{n_total}")
    for m, g in detected.items():
        print(f"    {m}: {len(g)}/{len(HUMAN_MODULES[m])} -> {g}")

    # ------------------------------------------------------------------
    # 2. Module scores + composite regenerative score
    # ------------------------------------------------------------------
    scores = pd.DataFrame({
        m: log2cpm.loc[detected[m]].mean(axis=0) for m in ["X", "Y", "Z"]
    })
    scores["RegScore"] = regscore(scores["X"], scores["Y"], scores["Z"], normalise=True)
    scores["Group"] = [c.split("_")[0] for c in scores.index]
    scores.index.name = "Sample"
    scores.round(5).to_csv(os.path.join(outdir, "module_scores.csv"))
    print("[GSE180504] module_scores.csv")
    print(scores.round(4).to_string())

    # ------------------------------------------------------------------
    # 3. Group-level summary (mean + individual replicates)
    # ------------------------------------------------------------------
    rows = []
    for g in GROUPS:
        sub = scores[scores["Group"] == g]
        if sub.empty:
            continue
        rows.append({
            "Condition": g,
            "RegScore_mean": round(float(sub["RegScore"].mean()), 4),
            "RegScore_replicate1": round(float(sub["RegScore"].iloc[0]), 4),
            "RegScore_replicate2": round(float(sub["RegScore"].iloc[1]), 4) if len(sub) > 1 else np.nan,
            "X_mean": round(float(sub["X"].mean()), 4),
            "Y_mean": round(float(sub["Y"].mean()), 4),
            "Z_mean": round(float(sub["Z"].mean()), 4),
            "N_samples": int(len(sub)),
        })
    reg = pd.DataFrame(rows)
    reg.to_csv(os.path.join(outdir, "regscore_summary.csv"), index=False)
    print("[GSE180504] regscore_summary.csv")
    print(reg.to_string(index=False))

    # ------------------------------------------------------------------
    # 4. Pairwise comparisons (directional only, n = 2)
    # ------------------------------------------------------------------
    comp_rows = []
    for a, b in [("T2D", "Lean"), ("Obese", "Lean"), ("T2D", "Obese")]:
        if a not in set(scores["Group"]) or b not in set(scores["Group"]):
            continue
        va = scores.loc[scores["Group"] == a, "RegScore"]
        vb = scores.loc[scores["Group"] == b, "RegScore"]
        comp_rows.append({
            "contrast": f"{a}_vs_{b}",
            "mean_A": round(float(va.mean()), 4),
            "mean_B": round(float(vb.mean()), 4),
            "delta": round(float(va.mean() - vb.mean()), 4),
            "n_per_group": int(len(va)),
            "note": "n=2/group; directional / hypothesis-generating only",
        })
    comp = pd.DataFrame(comp_rows)
    comp.to_csv(os.path.join(outdir, "group_comparison.csv"), index=False)
    print("[GSE180504] group_comparison.csv")
    print(comp.to_string(index=False))

    # ------------------------------------------------------------------
    # 5. Machine-readable summary
    # ------------------------------------------------------------------
    t2d = reg.set_index("Condition").loc["T2D", "RegScore_mean"] if "T2D" in set(reg["Condition"]) else np.nan
    lean = reg.set_index("Condition").loc["Lean", "RegScore_mean"] if "Lean" in set(reg["Condition"]) else np.nan
    obese = reg.set_index("Condition").loc["Obese", "RegScore_mean"] if "Obese" in set(reg["Condition"]) else np.nan

    summary = {
        "dataset": "GSE180504",
        "n_samples": int(len(scores)),
        "n_per_group": 2,
        "marker_genes_detected": n_detected,
        "marker_genes_total": n_total,
        "detected_by_module": detected,
        "predictions": {
            "P4_pathological_deepening": {
                "test": "T2D lowers the composite regenerative score vs Lean",
                "RegScore_Lean": float(lean),
                "RegScore_Obese": float(obese),
                "RegScore_T2D": float(t2d),
                "delta_T2D_minus_Lean": round(float(t2d - lean), 4),
                "supported": bool(t2d < lean),
                "caveat": "n = 2 per group; directional, hypothesis-generating only",
            },
        },
    }
    write_json(summary, os.path.join(outdir, "validation_summary.json"))
    print("[GSE180504] validation_summary.json")
    print(f"[GSE180504] done -> {outdir}")


if __name__ == "__main__":
    main()
