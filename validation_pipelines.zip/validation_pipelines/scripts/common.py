#!/usr/bin/env python3
"""
Shared helpers for the BOLD transcriptomic validation pipelines.

Provides:
    * minmax()          -- min-max normalisation to [0, 1]
    * regscore()        -- composite regenerative score (identical to the ODE model)
    * module_score()    -- mean log-expression of a gene module
    * cohens_d()        -- Cohen's d effect size
    * ensure_dir()      -- mkdir -p helper
    * write_json()      -- deterministic JSON dump
"""

from __future__ import annotations

import json
import os
from typing import Iterable, Sequence

import numpy as np
import pandas as pd


# ---------------------------------------------------------------------------
# Composite regenerative score
# ---------------------------------------------------------------------------
def minmax(x: np.ndarray) -> np.ndarray:
    """Min-max normalise to [0, 1] with a small epsilon guard."""
    x = np.asarray(x, dtype=float)
    return (x - x.min()) / (x.max() - x.min() + 1e-10)


def regscore(X, Y, Z, normalise: bool = True) -> np.ndarray:
    """
    Composite regenerative score.

        Score = 0.4*Z + 0.4*Y + 0.2*(1 - X)

    Parameters
    ----------
    X, Y, Z : array-like
        Module scores. If ``normalise`` is True they are min-max scaled to
        [0, 1] first (this is what the manuscript does for every dataset).
    normalise : bool
        Whether to min-max normalise the inputs before combining.

    Returns
    -------
    np.ndarray
        Composite score in [0, 1].
    """
    X = np.asarray(X, dtype=float)
    Y = np.asarray(Y, dtype=float)
    Z = np.asarray(Z, dtype=float)
    if normalise:
        X, Y, Z = minmax(X), minmax(Y), minmax(Z)
    return 0.4 * Z + 0.4 * Y + 0.2 * (1.0 - X)


# ---------------------------------------------------------------------------
# Module scoring
# ---------------------------------------------------------------------------
def module_score(expr: pd.DataFrame, genes: Sequence[str], log2: bool = True) -> pd.Series:
    """
    Mean expression of a gene module across samples.

    Parameters
    ----------
    expr : pd.DataFrame
        Genes x samples matrix (already normalised, e.g. log2(CPM+1)).
    genes : sequence of str
        Gene symbols present in ``expr.index``.
    log2 : bool
        Kept for API symmetry; the caller is responsible for the transform.

    Returns
    -------
    pd.Series
        Mean module score indexed by sample.
    """
    found = [g for g in genes if g in expr.index]
    if not found:
        raise ValueError(f"None of the module genes were found: {list(genes)}")
    return expr.loc[found].mean(axis=0)


def detected_genes(expr_index: Iterable[str], genes: Sequence[str]) -> list:
    """Return the subset of ``genes`` present in ``expr_index``."""
    idx = set(expr_index)
    return [g for g in genes if g in idx]


# ---------------------------------------------------------------------------
# Statistics
# ---------------------------------------------------------------------------
def cohens_d(a: np.ndarray, b: np.ndarray) -> float:
    """Cohen's d for two independent samples (pooled SD)."""
    a = np.asarray(a, dtype=float)
    b = np.asarray(b, dtype=float)
    na, nb = len(a), len(b)
    if na < 2 or nb < 2:
        return float("nan")
    sp2 = ((na - 1) * a.var(ddof=1) + (nb - 1) * b.var(ddof=1)) / (na + nb - 2)
    if sp2 <= 0:
        return float("nan")
    return float((a.mean() - b.mean()) / np.sqrt(sp2))


# ---------------------------------------------------------------------------
# I/O helpers
# ---------------------------------------------------------------------------
def ensure_dir(path: str) -> str:
    os.makedirs(path, exist_ok=True)
    return path


def write_json(obj, path: str) -> None:
    """Deterministic JSON dump (sorted keys, 2-space indent)."""
    ensure_dir(os.path.dirname(path))
    with open(path, "w") as fh:
        json.dump(obj, fh, indent=2, sort_keys=True, default=str)
